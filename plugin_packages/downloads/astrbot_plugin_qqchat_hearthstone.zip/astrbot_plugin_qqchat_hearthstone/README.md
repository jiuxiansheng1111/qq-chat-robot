# 大肥鱼 · 炉石卡组与约战

按标准或狂野推荐与评估卡组，分析费用、符文和替换卡。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
