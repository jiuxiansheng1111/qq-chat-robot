from __future__ import annotations
import asyncio
import json
import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star
_LOGGER = logging.getLogger(__name__)
from .feature import Feature
def _get_result_or_none(event: AstrMessageEvent) -> Any | None:
    """读取前置处理器留下的事件结果。"""
    try:
        return event.get_result()
    except AttributeError:
        return None

def _is_stopped(event: AstrMessageEvent) -> bool:
    """检查事件是否已停止传播。"""
    is_stopped = getattr(event, "is_stopped", None)
    return bool(is_stopped()) if callable(is_stopped) else False

def _result_has_reply(result: Any | None) -> bool:
    """空结果不算已回复。"""
    if isinstance(result, str):
        return bool(result.strip())
    return bool(getattr(result, "chain", None))

class Plugin(Feature, Star):
    slug = 'hearthstone'
    label = '炉石卡组与约战'
    summary = '按标准或狂野推荐与评估卡组，分析费用、符文和替换卡。'
    turns = ('hs',)
    legacy = ()

    prepare_order = 40

    @filter.command("炉石", alias={"炉石卡组", "炉石分析", "炉石替换", "卡组分析", "替换卡"})
    async def decks(self, event: AstrMessageEvent):
        """按模式查询、分析卡组或选择替换卡。"""
        host = self.host()
        if host is not None:
            from app.astrbot_hearthstone import wake_command
            await wake_command(host, event)

    async def prepare(self, host, event, request, enabled):
        from app.astrbot_hearthstone import prepare
        await prepare(host, event, request, arena=False, cards=False)

    @filter.llm_tool(name="qqchat_hearthstone")
    async def qqchat_hearthstone(
        self, event: AstrMessageEvent, action: str = "recommend", mode: str = "",
        sort: str = "balanced", query: str = "", deck: str = "", player_class: str = "",
        deck_index: int = 1, budget: int = -1,
    ) -> str:
        """查炉石真实卡牌效果、标准/狂野卡组及胜率热度，分析代码和筛选替换卡。

        Args:
            action(string): recommend推荐、card查卡、analyze分析、replace替换、evaluate强度/合成建议。
            mode(string): standard标准、wild狂野；推荐留空则分两模式查询。
            sort(string): balanced综合、winrate胜率、popularity对局热度、community营地社区热度。
            query(string): 公开卡名/效果关键词、替换目标卡名；recommend/evaluate填卡组名，如20牧、20脏牧、海盗战/Pirate Warrior。
            deck(string): 完整炉石卡组代码或营地卡组详情链接；可省略以沿用本人刚选的卡组。
            player_class(string): 职业中文名或英文名，可省略。
            deck_index(number): 本人最近推荐中的第几套，从1开始。
            budget(number): 替换卡每张最高合成粉尘；-1不限。
        """
        host = self.host()
        if host is None:
            return '{"status":"unavailable","message":"请先启用大肥鱼共享运行时"}'
        self = host
        from app.astrbot_hearthstone import query as hearthstone_query
        result = await hearthstone_query(
            self, event, action=action, mode=mode, sort=sort, query=query, deck=deck,
            player_class=player_class, deck_index=deck_index, budget=budget,
        )
        if action == "card" and result.get("status") in {"ok", "not_found"}:
            from app.astrbot_turn_features import remember_lookup

            remember_lookup(self, event, "cards", query.strip(), mode=mode)
        return json.dumps(result, ensure_ascii=False)
