from __future__ import annotations
import asyncio
import json
import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star
_LOGGER = logging.getLogger(__name__)
from .feature import Feature
def _get_result_or_none(event: AstrMessageEvent) -> Any | None:
    """读取前置处理器留下的事件结果。"""
    try:
        return event.get_result()
    except AttributeError:
        return None

def _is_stopped(event: AstrMessageEvent) -> bool:
    """检查事件是否已停止传播。"""
    is_stopped = getattr(event, "is_stopped", None)
    return bool(is_stopped()) if callable(is_stopped) else False

def _result_has_reply(result: Any | None) -> bool:
    """空结果不算已回复。"""
    if isinstance(result, str):
        return bool(result.strip())
    return bool(getattr(result, "chain", None))

class Plugin(Feature, Star):
    slug = 'voice'
    label = '语音与音色'
    summary = '朗读消息、选择音色以及进入或退出语音模式。'
    turns = ()
    legacy = ('voice',)

    async def message(self, host, event):
        from app.astrbot_chat import handle_voice_exit
        if await handle_voice_exit(host.runtime, event):
            if host._companion_turns:
                host._companion_turns.voice_off(event)
            return True

    @filter.on_decorating_result(priority=0)
    async def voice_reply(self, event: AstrMessageEvent):
        host = self.host()
        if host is not None:
            from app.astrbot_chat import decorate_native_voice
            await decorate_native_voice(host.runtime, event)

    @filter.llm_tool(name="qqchat_send_voice")
    async def qqchat_send_voice(self, event: AstrMessageEvent, text: str, voice: str = "") -> str:
        """向当前QQ会话发送一条语音，用于用户要求语音或适合发一小段声音的聊天。默认大肥鱼声线，其他音色只改变声音，不切换人格。成功后不重复发送同一段文字。

        Args:
            text(string): 本次实际朗读的自然口语，保持大肥鱼语气，不放工具说明或内部提示。
            voice(string): 留空用当前选择或默认大肥鱼，也可用音色菜单里的名字。
        """
        host = self.host()
        if host is None:
            return '{"status":"unavailable","message":"请先启用大肥鱼共享运行时"}'
        self = host
        from app.astrbot_qq_persona import is_qq
        from app.services.qq_voice import qq_voice_settings
        from app.services.voice import resolve_character_profile, synthesize_voice
        if not is_qq(event) or self.runtime is None:
            return '{"status":"unavailable"}'
        raw=getattr(event.message_obj,"raw_message",None)
        if not await self._legacy_event_allowed(raw):
            return '{"status":"denied"}'
        core=self.runtime._core
        settings=qq_voice_settings(core.settings)
        if not settings.voice_enabled:
            return '{"status":"disabled","message":"语音功能尚未开启"}'
        self_id=str((raw or {}).get("self_id", ""))
        profile=resolve_character_profile(settings,voice,self_id) if voice else settings.voice_profile_default
        if not profile:
            return '{"status":"unknown_voice","message":"没有这个可用音色，请查音色菜单"}'
        if not voice and (raw or {}).get("group_id"):
            profile=await core.app.state.db.voice_profile(str(raw["group_id"]),str(raw.get("user_id","")),profile)
        limiter=getattr(core.app.state,"voice_send_limiter",None)
        if limiter is not None and not await limiter.allow(str(event.unified_msg_origin)+":"+str((raw or {}).get("user_id",""))):
            return '{"status":"rate_limited","message":"刚发过语音，先正常用文字聊天"}'
        try:
            from astrbot.api.message_components import Record
            record=await synthesize_voice(text,settings,profile,bot_self_id=self_id)
            await event.send(event.chain_result([Record(file=record,text=text)]))
            from app.services.owner_memory import record_assistant
            try:
                await asyncio.to_thread(record_assistant,event,text,source="voice")
            except Exception as exc:
                _LOGGER.warning("主人语音原文本次未归档（%s）",type(exc).__name__)
            return '{"status":"sent","message":"本条语音已发送，不重复发送"}'
        except Exception:
            return '{"status":"failed","message":"语音未发送成功，请用完整文字接着回复，不要说已经发出"}'
