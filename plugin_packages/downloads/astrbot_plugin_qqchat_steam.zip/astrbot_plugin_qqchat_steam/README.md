# 大肥鱼 · Steam 大厅

绑定专用 SteamID，核对本机账号并接收大厅邀请。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
