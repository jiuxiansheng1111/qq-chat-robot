# 大肥鱼 · 群聊约局

在群里报开黑时间、报名或候补，汇总缺几人和最早开局时间，支持改期和退出。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
