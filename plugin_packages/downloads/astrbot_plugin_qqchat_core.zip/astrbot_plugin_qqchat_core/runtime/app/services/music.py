import json
import re
import unicodedata
from dataclasses import dataclass
from urllib.parse import urlparse

from app.config import Settings
from app.services.bounded_http import request_json
from app.services.http_routing import outbound_http_client


@dataclass(frozen=True)
class MusicTrack:
    title: str
    artist: str
    album: str
    page_url: str
    preview_url: str
    cover_url: str
    duration_seconds: int


@dataclass(frozen=True)
class NeteaseTrack:
    song_id: str
    title: str
    artists: tuple[str, ...]
    album: str
    cover_url: str
    duration_seconds: int
    title_aliases: tuple[str, ...] = ()
    artist_aliases: tuple[str, ...] = ()

    @property
    def artist(self) -> str:
        return "/".join(self.artists)

    @property
    def page_url(self) -> str:
        return f"https://music.163.com/#/song?id={self.song_id}"


@dataclass(frozen=True)
class MusicIdentity:
    title: str
    artist: str
    search_query: str


def parse_music_identity(value: str) -> MusicIdentity | None:
    value = value.strip()
    fenced = re.search(r"\{.*\}", value, re.DOTALL)
    if not fenced:
        return None
    try:
        data = json.loads(fenced.group(0))
    except (json.JSONDecodeError, TypeError):
        return None
    if not isinstance(data, dict):
        return None
    title = str(data.get("title") or "").strip()[:120]
    artist = str(data.get("artist") or "").strip()[:100]
    search_query = str(data.get("search_query") or "").strip()[:120]
    if not title or not artist:
        return None
    return MusicIdentity(title, artist, search_query or f"{artist} {title}")


UNOFFICIAL_VERSION_MARKERS = (
    "cover",
    "remix",
    "karaoke",
    "instrumental",
    "piano",
    "acoustic",
    "翻唱",
    "伴奏",
    "纯音乐",
    "钢琴",
    "吉他",
    "原曲歌手",
    "カラオケ",
)


def normalize_music_text(value: str) -> str:
    value = unicodedata.normalize("NFKC", value).casefold()
    return "".join(character for character in value if character.isalnum())


_ARTIST_NAMES = {"ヨルシカ": ("ヨルシカ", "yorushika", "yolushika", "夜鹿")}
# 官方曲目：https://yorushika.com/discography/detail/6/
_TITLE_NAMES = {("ヨルシカ", "parade"): "パレード"}


def canonical_music_artist(value: str) -> str:
    normalized = normalize_music_text(value)
    for name, aliases in _ARTIST_NAMES.items():
        if normalized in {normalize_music_text(alias) for alias in aliases}:
            return name
    return value.strip()


def music_query_identity(query: str) -> MusicIdentity | None:
    """保留明确的歌手约束；只使用核实过的跨语言别名。"""
    explicit = re.split(r"\s*[/／]\s*|\s+[-–—]\s+", query, maxsplit=1)
    if len(explicit) == 2 and all(part.strip() for part in explicit):
        title, artist = explicit[0].strip(), canonical_music_artist(explicit[1])
    else:
        artist = title = ""
        for name, aliases in _ARTIST_NAMES.items():
            for alias in aliases:
                # 英文别名需要词边界，避免把相似长单词当成歌手。
                pattern = re.escape(alias)
                if alias.isascii():
                    pattern = rf"(?<![a-z0-9_]){pattern}(?![a-z0-9_])"
                match = re.search(pattern, query, re.IGNORECASE)
                if match:
                    artist = name
                    title = (query[:match.start()] + query[match.end():]).strip(" 的：:-–—")
                    break
            if artist:
                break
        if not artist or not title:
            return None
    title = _TITLE_NAMES.get((artist, normalize_music_text(title)), title)
    return MusicIdentity(title, artist, f"{artist} {title}")


def netease_title_names(track: NeteaseTrack) -> tuple[str, ...]:
    """别名也可能是用户熟悉的英文歌名。"""
    return (track.title, *track.title_aliases)


def netease_artist_names(track: NeteaseTrack) -> tuple[str, ...]:
    names = (*track.artists, *track.artist_aliases)
    return tuple(dict.fromkeys((*names, *(canonical_music_artist(name) for name in names))))


def _music_aliases(item: dict, *fields: str) -> tuple[str, ...]:
    result: list[str] = []
    for field in fields:
        values = item.get(field)
        if isinstance(values, str):
            values = [values]
        if not isinstance(values, list):
            continue
        for value in values[:16]:
            if isinstance(value, str) and value.strip():
                alias = value.strip()[:120]
                if alias not in result:
                    result.append(alias)
    return tuple(result[:16])


def music_query_suffixes(query: str) -> list[str]:
    """从歌手/歌名混合查询中，稳定地生成备用标题候选。"""
    tokens = query.split()
    if len(tokens) < 2:
        return []
    candidates: list[str] = []
    for start in range(1, len(tokens)):
        candidate = " ".join(tokens[start:]).strip()
        if candidate and candidate not in candidates:
            candidates.append(candidate)
    return candidates


def parse_netease_tracks(payload: dict) -> list[NeteaseTrack]:
    result = payload.get("result") if isinstance(payload, dict) else None
    songs = result.get("songs", []) if isinstance(result, dict) else []
    tracks: list[NeteaseTrack] = []
    for item in songs if isinstance(songs, list) else []:
        if not isinstance(item, dict):
            continue
        artist_items = item.get("artists") or item.get("ar") or []
        if not isinstance(artist_items, list):
            continue
        artists = tuple(
            str(artist.get("name", "")).strip()[:120]
            for artist in artist_items[:16]
            if isinstance(artist, dict) and str(artist.get("name", "")).strip()
        )
        album_data = item.get("album") or item.get("al") or {}
        if not isinstance(album_data, dict):
            album_data = {}
        song_id = str(item.get("id") or "").strip()
        title = str(item.get("name") or "").strip()
        if not re.fullmatch(r"[0-9]{1,20}", song_id) or not title or not artists:
            continue
        try:
            duration = max(0, int(item.get("duration") or item.get("dt") or 0) // 1000)
        except (ValueError, TypeError, OverflowError):
            duration = 0
        tracks.append(
            NeteaseTrack(
                song_id=song_id,
                title=title[:120],
                artists=artists,
                album=str(album_data.get("name") or "")[:120],
                cover_url=_https_url(
                    album_data.get("picUrl"), ("music.126.net",), allow_upgrade=True,
                ),
                duration_seconds=duration,
                title_aliases=_music_aliases(item, "alias", "alia", "tns", "transNames"),
                artist_aliases=tuple(dict.fromkeys(
                    alias for artist in artist_items[:16] if isinstance(artist, dict)
                    for alias in _music_aliases(artist, "alias", "tns", "trans", "transNames")
                ))[:32],
            )
        )
    return tracks


def choose_netease_track(
    query: str, tracks: list[NeteaseTrack], expected_artist: str = "", expected_title: str = ""
) -> NeteaseTrack | None:
    ranked = rank_netease_tracks(query, tracks, expected_artist, expected_title)
    return ranked[0] if ranked else None


def rank_netease_tracks(
    query: str, tracks: list[NeteaseTrack], expected_artist: str = "", expected_title: str = ""
) -> list[NeteaseTrack]:
    """稳定选择目标歌曲；除非用户明确点名版本，否则排除翻唱。"""
    identity = music_query_identity(query)
    if identity is not None:
        expected_artist = expected_artist or identity.artist
        expected_title = expected_title or identity.title
    query_norm = normalize_music_text(query)
    artist_norm = normalize_music_text(canonical_music_artist(expected_artist))
    title_norm = normalize_music_text(expected_title)
    requested_version = any(marker in query.casefold() for marker in UNOFFICIAL_VERSION_MARKERS)
    ranked: list[tuple[tuple[int, int, int, int], NeteaseTrack]] = []
    for index, track in enumerate(tracks):
        combined = f"{track.title} {track.artist}".casefold()
        unofficial = any(marker in combined for marker in UNOFFICIAL_VERSION_MARKERS)
        if unofficial and not requested_version:
            continue
        track_titles = [normalize_music_text(title) for title in netease_title_names(track)]
        track_artists = [normalize_music_text(artist) for artist in netease_artist_names(track)]
        exact_title = (title_norm or query_norm) in track_titles
        artist_match = bool(
            artist_norm
            and any(
                artist_norm == artist or artist_norm in artist or artist in artist_norm
                for artist in track_artists if artist
            )
        )
        if artist_norm and not artist_match:
            continue
        if title_norm and not exact_title:
            continue
        query_match = any(title and title in query_norm for title in track_titles)
        score = (
            0 if artist_match else 1,
            0 if exact_title else 1,
            0 if query_match else 1,
            index,
        )
        ranked.append((score, track))
    return [item[1] for item in sorted(ranked, key=lambda item: item[0])]


def netease_track_matches_query(query: str, track: NeteaseTrack) -> bool:
    identity = music_query_identity(query)
    if identity is not None:
        return bool(rank_netease_tracks(query, [track], identity.artist, identity.title))
    query_norm = normalize_music_text(query)
    titles = [normalize_music_text(title) for title in netease_title_names(track)]
    if not query_norm:
        return False
    if query_norm in titles:
        return True
    return any(title and title in query_norm for title in titles) and any(
        artist and artist in query_norm
        for artist in (normalize_music_text(name) for name in netease_artist_names(track))
    )


def _https_url(
    value: object, allowed_suffixes: tuple[str, ...], *, allow_upgrade: bool = False,
) -> str:
    url = str(value or "").strip()
    try:
        parsed = urlparse(url)
        host = (parsed.hostname or "").lower()
        valid_host = any(
            host == suffix or host.endswith("." + suffix) for suffix in allowed_suffixes
        )
        if (
            len(url) > 2048 or not valid_host or parsed.username or parsed.password
            or parsed.fragment or parsed.port not in (None, 443)
        ):
            return ""
        # 网易云旧接口有时返回 HTTP 封面，同一 CDN 只用 HTTPS 读取。
        if allow_upgrade and parsed.scheme == "http":
            return parsed._replace(scheme="https").geturl()
        if parsed.scheme != "https":
            return ""
    except ValueError:
        return ""
    return url


def parse_deezer_tracks(payload: dict) -> list[MusicTrack]:
    items = payload.get("data") if isinstance(payload, dict) else None
    tracks: list[MusicTrack] = []
    seen: set[tuple[str, str]] = set()
    for item in items if isinstance(items, list) else []:
        if not isinstance(item, dict) or item.get("explicit_lyrics") is True:
            continue
        artist_data = item.get("artist") if isinstance(item.get("artist"), dict) else {}
        album_data = item.get("album") if isinstance(item.get("album"), dict) else {}
        title = str(item.get("title_short") or item.get("title") or "").strip()
        artist = str(artist_data.get("name") or "").strip()
        preview = _https_url(item.get("preview"), ("dzcdn.net",))
        page = _https_url(item.get("link"), ("deezer.com",))
        if not title or not artist or not preview or not page:
            continue
        key = (title.casefold(), artist.casefold())
        if key in seen:
            continue
        seen.add(key)
        tracks.append(
            MusicTrack(
                title=title[:120],
                artist=artist[:100],
                album=str(album_data.get("title") or "")[:120],
                page_url=page,
                preview_url=preview,
                cover_url=_https_url(
                    album_data.get("cover_xl")
                    or album_data.get("cover_big")
                    or album_data.get("cover_medium"),
                    ("dzcdn.net",),
                ),
                duration_seconds=max(0, int(item.get("duration") or 0)),
            )
        )
    return tracks


async def search_music(query: str, settings: Settings) -> list[MusicTrack]:
    query = " ".join(query.split()).strip()[:120]
    if not query:
        return []
    async with outbound_http_client(timeout=settings.music_timeout_seconds) as client:
        response = await client.get(
            f"{settings.music_api_url.rstrip('/')}/search",
            params={"q": query, "limit": max(1, min(settings.music_search_limit, 25))},
            headers={"User-Agent": "qq-chatrobot/0.1 (personal music discovery bot)"},
        )
        response.raise_for_status()
        return parse_deezer_tracks(response.json())


async def search_netease_music(query: str, settings: Settings) -> list[NeteaseTrack]:
    query = re.sub(r"\s+", " ", query).strip()[:120]
    if not query:
        return []
    headers = {
        "User-Agent": "Mozilla/5.0 qq-chatrobot/0.1",
        "Referer": "https://music.163.com/",
    }
    data = {
        "s": query,
        "type": "1",
        "limit": str(max(5, min(settings.music_search_limit, 25))),
        "offset": "0",
        "total": "true",
    }
    async with outbound_http_client(timeout=settings.music_timeout_seconds) as client:
        payload = await request_json(
            client, "POST", settings.netease_music_api_url, data=data, headers=headers,
            timeout_seconds=max(1, settings.music_timeout_seconds),
        )
        return parse_netease_tracks(payload)
