# 大肥鱼 · 共享运行时

为已安装的功能提供连接、数据库、会话隔离和消息分发。

在 AstrBot 的插件页选择「从文件安装」，启用后再装需要的功能。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
