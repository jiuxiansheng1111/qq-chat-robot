from __future__ import annotations
import asyncio
import json
import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star
_LOGGER = logging.getLogger(__name__)
def _get_result_or_none(event: AstrMessageEvent) -> Any | None:
    """读取前置处理器留下的事件结果。"""
    try:
        return event.get_result()
    except AttributeError:
        return None

def _is_stopped(event: AstrMessageEvent) -> bool:
    """检查事件是否已停止传播。"""
    is_stopped = getattr(event, "is_stopped", None)
    return bool(is_stopped()) if callable(is_stopped) else False

def _result_has_reply(result: Any | None) -> bool:
    """空结果不算已回复。"""
    if isinstance(result, str):
        return bool(result.strip())
    return bool(getattr(result, "chain", None))

class HostSupport:
    def _get_companion_turns(self):
        if self._companion_turns is None:
            from app.astrbot_companion_turns import CompanionTurns

            self._companion_turns = CompanionTurns()
        return self._companion_turns

    def _get_group_router(self) -> Any:
        if self._group_router is None:
            from app.astrbot_group_chat import GroupChatRouter
            from app.astrbot_identity import CHARACTER_NAME
            from app.astrbot_listening import ALIASES

            routing_config = dict(self.config)
            names = routing_config.get("group_chat_bot_names", [])
            if isinstance(names, str):
                names = [names]
            routing_config["group_chat_bot_names"] = list(dict.fromkeys([*(names or []), CHARACTER_NAME, *ALIASES]))
            self._group_router = GroupChatRouter(routing_config)
        return self._group_router

    def _get_qq_memes(self) -> Any:
        if self._qq_memes is None:
            from app.astrbot_memes import QQMemes

            self._qq_memes = QQMemes()
        return self._qq_memes

    def _get_reply_guard(self) -> Any:
        if self._reply_guard is None:
            from app.astrbot_reply_guard import GroupReplyGuard

            self._reply_guard = GroupReplyGuard(
                cache_path=self.root / "data/astrbot/group-reply-guard.json",
            )
        return self._reply_guard

    def _get_reply_repair(self) -> Any:
        if self._reply_repair is None:
            from app.astrbot_reply_repair import DirectReplyRepair

            self._reply_repair = DirectReplyRepair(self._get_reply_guard())
        return self._reply_repair

    async def _legacy_event_allowed(self, raw_event: Mapping[str, Any] | None) -> bool:
        """沿用旧群开关和黑名单，避免高优先级菜单绕过限制。"""
        if raw_event is None:
            return False
        if raw_event.get("message_type") != "group":
            return True
        group_id = str(raw_event.get("group_id") or "").strip()
        user_id = str(raw_event.get("user_id") or "").strip()
        core = getattr(self.runtime, "_core", None)
        database = getattr(getattr(core, "app", None), "state", None)
        database = getattr(database, "db", None)
        if not group_id or not user_id or database is None:
            return False
        try:
            if not await database.group_enabled(group_id):
                return False
            return not await database.is_blocked(group_id, user_id)
        except Exception:
            _LOGGER.exception("检查旧群开关或黑名单失败，暂不处理菜单请求")
            return False

    async def on_onebot_message(self, event: AstrMessageEvent) -> None:
        """把原始 OneBot 消息交给现有分发器。

        默认优先级为 0；负优先级让常规处理器先运行。
        """
        raw_message = getattr(getattr(event, "message_obj", None), "raw_message", None)
        if not isinstance(raw_message, Mapping):
            if self.legacy_chat:
                event.should_call_llm(False)
            return
        raw_event = dict(raw_message)
        if raw_event.get("post_type") != "message" or raw_event.get("message_type") not in {"group", "private"}:
            return
        if (self.legacy_chat and getattr(self.runtime, "project_root", None) and not _is_stopped(event)
                and not _result_has_reply(_get_result_or_none(event)) and not getattr(event, "_has_send_oper", False)
                and not self._get_group_router().ignored_sender(event) and await self._legacy_event_allowed(raw_event)):
            from app.astrbot_weather import handle_command as handle_weather
            if await handle_weather(self, event):
                return
            if await self._get_companion_turns().handle(self, event, features={"meetups", "followups"}):
                return
        if raw_event["message_type"] == "private":
            from app.astrbot_group_chat import normalized_runtime_event
            from app.main import private_command

            core = getattr(self.runtime, "_core", None)
            if private_command(normalized_runtime_event(event, raw_event), getattr(getattr(core, "app", None), "state", None)) is None:
                return

        stopped = _is_stopped(event)
        prior_result = _get_result_or_none(event)
        prior_reply = _result_has_reply(prior_result)
        prior_send = bool(getattr(event, "_has_send_oper", False))

        # 旧聊天模式由本插件负责；已有结果或回复时避免再次回答。
        if self.legacy_chat or stopped or prior_reply or prior_send:
            event.should_call_llm(False)

        if stopped or prior_reply or prior_send:
            return

        if self.runtime is None:
            raise RuntimeError("聊天机器人插件尚未初始化")

        # 保留原始消息段，避免丢失 @、回复、图片、音频和视频。
        # 不把机器人自己的回显再次派发。
        user_id = raw_event.get("user_id")
        self_id = raw_event.get("self_id")
        if user_id is not None and self_id is not None and str(user_id) == str(self_id):
            event.should_call_llm(False)
            return

        from app.astrbot_group_chat import normalized_runtime_event

        get_extra = getattr(event, "get_extra", None)
        if callable(get_extra) and get_extra("qqchat_skip_local_command", False):
            return
        raw_event = normalized_runtime_event(event, raw_event)
        if not self.legacy_chat:
            from app.services.owner_memory import archive,event_owner
            owner=event_owner(event)
            # Keep the established explicit clear command consistent with the
            # new source archive as well as the old manual-note table.
            if owner is not None and await self._legacy_event_allowed(raw_event):
                from app.main import LONG_MEMORY_CLEAR_COMMANDS,message_text,bot_mentioned
                clear_text=message_text(raw_event)
                if clear_text in LONG_MEMORY_CLEAR_COMMANDS and (clear_text.startswith("/") or bot_mentioned(raw_event)):
                    await asyncio.to_thread(archive().forget,owner,all_records=True)
                    from app.astrbot_soundtry import SoundtryJobs
                    await asyncio.to_thread(self._get_music_listening().memory.forget,SoundtryJobs.owner(event))
        bot_api = event.bot.api

        async def action_call(action: str, **params: Any) -> dict[str, Any]:
            """通过 AstrBot 的 OneBot 客户端调用协议端 API。"""
            if self_id is not None:
                params["self_id"] = str(self_id)
            if action in {"send_group_msg","send_private_msg","send_msg"}:
                from app.astrbot_failure_reply import rewrite_raw_text
                message=params.get("message","")
                if isinstance(message,str):
                    params["message"]=await rewrite_raw_text(self.context,event,message)
                elif isinstance(message,list):
                    # Preserve all media, quotes and forwarding nodes verbatim.
                    for segment in message:
                        if isinstance(segment,dict) and segment.get("type")=="text" and isinstance(segment.get("data"),dict):
                            segment["data"]["text"]=await rewrite_raw_text(self.context,event,str(segment["data"].get("text","")))
            reply=await bot_api.call_action(action, **params)
            if action in {"send_group_msg","send_private_msg"}:
                from app.services.owner_memory import record_assistant
                message=params.get("message","")
                text=(message if isinstance(message,str) else "".join(
                    str(p.get("data",{}).get("text","")) for p in message
                    if isinstance(p,dict) and p.get("type")=="text") if isinstance(message,list) else "")
                if text and (not isinstance(reply,dict) or reply.get("retcode",0)==0):
                    try:
                        await asyncio.to_thread(record_assistant,event,text,source="command")
                    except Exception as exc:
                        _LOGGER.warning("主人命令回复本次未归档（%s）",type(exc).__name__)
            return reply

        from app.astrbot_llm import model_session

        with model_session(getattr(event, "unified_msg_origin", None)):
            result = await self.runtime.handle_event(raw_event, action_call)
        if result.get("music_query"):
            from app.astrbot_turn_features import remember_lookup

            remember_lookup(self, event, "music", result["music_query"])
        if result.get("handled"):
            event.should_call_llm(False)
            event.stop_event()
        elif not self.legacy_chat and result.get("native_chat_requested"):
            event.is_at_or_wake_command = True

    async def on_wechat_message(self, event: AstrMessageEvent) -> None:
        """微信私聊和群聊共用业务功能，账号和会话各自隔离。"""
        get_name = getattr(event, "get_platform_name", None)
        name = str(get_name() if callable(get_name) else "").casefold()
        if not any(tag in name for tag in ("weixin", "wechat", "wecom")):
            return
        if (
            _is_stopped(event)
            or _result_has_reply(_get_result_or_none(event))
            or getattr(event, "_has_send_oper", False)
        ):
            return
        from app.astrbot_wechat import WeChatTransport

        platform_id = str(event.get_platform_id())
        account_id = str(getattr(getattr(event, "platform", None), "account_id", "") or "")
        key = (platform_id, account_id)
        bridge = self._wechat_bridges.get(key)
        if bridge is None:
            bridge = WeChatTransport(
                self.context, platform_id=platform_id,
                account_id=account_id or None, platform_name=name,
            )
            self._wechat_bridges[key] = bridge
        raw_event = bridge.bind_event(event)
        if raw_event is None:
            return
        if self.runtime is None:
            raise RuntimeError("聊天机器人插件尚未初始化")
        if self.legacy_chat:
            event.should_call_llm(False)
        from app.astrbot_llm import model_session

        with model_session(getattr(event, "unified_msg_origin", None)):
            result = await self.runtime.handle_event(raw_event, bridge.action_call)
        if result.get("handled"):
            event.should_call_llm(False)
            event.stop_event()
        elif not self.legacy_chat and result.get("native_chat_requested"):
            event.is_at_or_wake_command = True
