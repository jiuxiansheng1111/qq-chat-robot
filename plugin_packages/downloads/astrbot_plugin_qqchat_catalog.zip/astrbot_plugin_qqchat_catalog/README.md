# 大肥鱼 · 日漫与特摄图鉴

查询角色资料、别名和图片，管理抽取与收藏。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
