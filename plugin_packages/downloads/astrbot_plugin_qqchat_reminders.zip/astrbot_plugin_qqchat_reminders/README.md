# 大肥鱼 · 提醒与待办

从聊天提取待办，经本人确认后保存，并可完成或取消。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
