# 大肥鱼 · 无剧透追番

按本人明确要求记住作品和集数，用已看集数的分集资料和当前截图讨论。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
