# 大肥鱼 · 音频分析

通过 SoundTry 分析当前或引用的真实音频附件。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
