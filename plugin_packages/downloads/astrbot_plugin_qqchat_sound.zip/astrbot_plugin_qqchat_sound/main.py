from __future__ import annotations
import asyncio
import json
import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star
_LOGGER = logging.getLogger(__name__)
from .feature import Feature
def _get_result_or_none(event: AstrMessageEvent) -> Any | None:
    """读取前置处理器留下的事件结果。"""
    try:
        return event.get_result()
    except AttributeError:
        return None

def _is_stopped(event: AstrMessageEvent) -> bool:
    """检查事件是否已停止传播。"""
    is_stopped = getattr(event, "is_stopped", None)
    return bool(is_stopped()) if callable(is_stopped) else False

def _result_has_reply(result: Any | None) -> bool:
    """空结果不算已回复。"""
    if isinstance(result, str):
        return bool(result.strip())
    return bool(getattr(result, "chain", None))

class Plugin(Feature, Star):
    slug = 'sound'
    label = '音频分析'
    summary = '通过 SoundTry 分析当前或引用的真实音频附件。'
    turns = ()
    legacy = ()

    async def prepare(self, host, event, request, enabled):
        from app.astrbot_soundtry import prepare_soundtry
        prepare_soundtry(event, request, host._soundtry_jobs)

    @filter.llm_tool(name="qqchat_sound_analyze")
    async def qqchat_sound_analyze(self, event: AstrMessageEvent, mode: str = "read", attachment: int = 0) -> str:
        """本地听取本轮或引用的音频/视频附件，转写或分析音乐；后台执行，期间可以正常聊天，完成后主动返回实际结果。

        Args:
            mode(string): read综合听取、transcribe语音歌词转写、rhythm节奏、melody旋律、chords和弦、structure段落。只能选择其中一个。
            attachment(number): 当前真实附件的序号，从0开始。不能传入文件路径或其他用户的附件。
        """
        host = self.host()
        if host is None:
            return '{"status":"unavailable","message":"请先启用大肥鱼共享运行时"}'
        self = host
        from app.astrbot_qq_persona import is_qq

        if not is_qq(event) or self.runtime is None:
            return '{"status":"unavailable"}'
        raw = getattr(getattr(event,"message_obj",None),"raw_message",None)
        if not await self._legacy_event_allowed(raw):
            return '{"status":"denied"}'
        self._get_music_listening()
        if isinstance(attachment,float) and attachment.is_integer():
            attachment = int(attachment)
        return self._soundtry_jobs.start(event,self.runtime._core.settings,self.context,mode,attachment)

    @filter.on_llm_response(priority=1000002)
    async def defer_background_analysis_receipt(self, event: AstrMessageEvent, response: Any) -> None:
        host = self.host()
        if host is None:
            return
        self = host
        from app.astrbot_analysis_delivery import defer_model_receipt

        defer_model_receipt(event,response)

    @filter.on_decorating_result(priority=1000002)
    async def suppress_background_analysis_receipt(self, event: AstrMessageEvent) -> None:
        host = self.host()
        if host is None:
            return
        self = host
        from app.astrbot_analysis_delivery import suppress_model_receipt

        if suppress_model_receipt(event) and self._group_router is not None:
            self._group_router.finish_event(event)
