# 大肥鱼 · Minecraft 工程备料

生成建筑图纸，采集材料存入指定坐标的箱子，按上次实际开箱结果报告进度。搭配 Minecraft 独立玩家进服。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
