from __future__ import annotations
import asyncio
import json
import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star
_LOGGER = logging.getLogger(__name__)
from .feature import Feature
def _get_result_or_none(event: AstrMessageEvent) -> Any | None:
    """读取前置处理器留下的事件结果。"""
    try:
        return event.get_result()
    except AttributeError:
        return None

def _is_stopped(event: AstrMessageEvent) -> bool:
    """检查事件是否已停止传播。"""
    is_stopped = getattr(event, "is_stopped", None)
    return bool(is_stopped()) if callable(is_stopped) else False

def _result_has_reply(result: Any | None) -> bool:
    """空结果不算已回复。"""
    if isinstance(result, str):
        return bool(result.strip())
    return bool(getattr(result, "chain", None))

class Plugin(Feature, Star):
    slug = 'usage'
    label = '模型用量'
    summary = '按使用记录查询模型用量。'
    turns = ()
    legacy = ()

    @filter.llm_tool(name="qqchat_token_usage")
    async def qqchat_token_usage(self, event: AstrMessageEvent) -> str:
        """仅主人可查看当前QQ会话真实记录的Token用量，不含聊天原文、配置、账号或凭据。缺失统计为未知，不能当作订阅剩余额度。
        """
        host = self.host()
        if host is None:
            return '{"status":"unavailable","message":"请先启用大肥鱼共享运行时"}'
        self = host
        from app.services.owner_memory import event_owner
        from app.services.usage_ledger import bind_event, ledger
        if self.runtime is None or event_owner(event) is None or not await self._legacy_event_allowed(getattr(event.message_obj,"raw_message",None)):
            return '{"status":"denied"}'
        scope=bind_event(event)["scope_hash"]
        return json.dumps(await asyncio.to_thread(ledger().report,scope_hash=scope),ensure_ascii=False)
