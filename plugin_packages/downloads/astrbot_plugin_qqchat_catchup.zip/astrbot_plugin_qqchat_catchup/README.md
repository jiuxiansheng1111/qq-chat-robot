# 大肥鱼 · 群聊补课

在群里询问刚才的重点、安排和待确认事项。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
