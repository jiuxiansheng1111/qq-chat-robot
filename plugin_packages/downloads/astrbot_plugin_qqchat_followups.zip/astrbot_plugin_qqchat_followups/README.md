# 大肥鱼 · 约定回访

聊到自己的面试、考试等安排时可约定回访，确认后按北京时间回到原群或私聊问候。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
