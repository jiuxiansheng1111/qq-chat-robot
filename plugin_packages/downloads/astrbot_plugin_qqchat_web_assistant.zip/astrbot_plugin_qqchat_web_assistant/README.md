# 大肥鱼 · 网页助手

主人私聊发送网址，读取网页、翻页、点击文字按钮或填写带标签的输入框。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
