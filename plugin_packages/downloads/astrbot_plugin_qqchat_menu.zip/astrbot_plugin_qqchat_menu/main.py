from __future__ import annotations
import asyncio
import json
import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star
_LOGGER = logging.getLogger(__name__)
from .feature import Feature
def _get_result_or_none(event: AstrMessageEvent) -> Any | None:
    """读取前置处理器留下的事件结果。"""
    try:
        return event.get_result()
    except AttributeError:
        return None

def _is_stopped(event: AstrMessageEvent) -> bool:
    """检查事件是否已停止传播。"""
    is_stopped = getattr(event, "is_stopped", None)
    return bool(is_stopped()) if callable(is_stopped) else False

def _result_has_reply(result: Any | None) -> bool:
    """空结果不算已回复。"""
    if isinstance(result, str):
        return bool(result.strip())
    return bool(getattr(result, "chain", None))

class Plugin(Feature, Star):
    slug = 'menu'
    label = '功能菜单'
    summary = '列出当前会话已启用的分件及使用方式。'
    turns = ()
    legacy = ()

    @filter.command("肥鱼插件", alias={"肥鱼菜单", "大肥鱼菜单"})
    async def show_modules(self, event: AstrMessageEvent):
        """列出本会话实际启用的大肥鱼功能。"""
        host = self.host()
        if host is None:
            return
        from app.astrbot_menu import _raw_event_for_reset
        if not await host._legacy_event_allowed(_raw_event_for_reset(host, event)):
            return
        text = "\n".join(part.label + "  " + part.summary for part in sorted(host.parts(event), key=lambda p: p.label))
        await event.send(event.plain_result("本会话已启用的功能\n" + text))
        event.should_call_llm(False)
        event.stop_event()

    async def message(self, host, event):
        from app.astrbot_menu import menu_request_kind
        text = event.get_message_str().strip().lstrip("/")
        if text in {"肥鱼菜单", "大肥鱼菜单", "肥鱼插件"} or menu_request_kind(text):
            await self.show_modules(event)
            return True
