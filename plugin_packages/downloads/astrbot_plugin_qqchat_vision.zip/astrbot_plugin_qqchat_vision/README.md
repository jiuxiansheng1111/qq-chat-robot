# 大肥鱼 · 图片理解与对比

读取群图、截图，在对话中比对两张图片和局部差异。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
