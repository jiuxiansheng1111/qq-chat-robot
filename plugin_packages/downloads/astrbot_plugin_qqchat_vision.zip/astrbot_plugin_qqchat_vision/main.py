from __future__ import annotations
import asyncio
import json
import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star
_LOGGER = logging.getLogger(__name__)
from .feature import Feature
def _get_result_or_none(event: AstrMessageEvent) -> Any | None:
    """读取前置处理器留下的事件结果。"""
    try:
        return event.get_result()
    except AttributeError:
        return None

def _is_stopped(event: AstrMessageEvent) -> bool:
    """检查事件是否已停止传播。"""
    is_stopped = getattr(event, "is_stopped", None)
    return bool(is_stopped()) if callable(is_stopped) else False

def _result_has_reply(result: Any | None) -> bool:
    """空结果不算已回复。"""
    if isinstance(result, str):
        return bool(result.strip())
    return bool(getattr(result, "chain", None))

class Plugin(Feature, Star):
    slug = 'vision'
    label = '图片理解与对比'
    summary = '读取群图、截图，在对话中比对两张图片和局部差异。'
    turns = ('compare',)
    legacy = ()

    prepare_order = 25

    async def start_part(self, host):
        from app.astrbot_vision_provider import register_vision_provider
        register_vision_provider()

    async def prepare(self, host, event, request, enabled):
        from app.astrbot_vision import prepare_group_image_context
        from app.astrbot_search import _text_only_chat_provider
        prepare_group_image_context(event, request, text_only=await _text_only_chat_provider(host.context, event))
