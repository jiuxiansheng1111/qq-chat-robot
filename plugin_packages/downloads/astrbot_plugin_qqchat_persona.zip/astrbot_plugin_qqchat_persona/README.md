# 大肥鱼 · 大肥鱼聊天与群聊接话

统一 QQ 人格、群聊接话、去重和回复修复。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
