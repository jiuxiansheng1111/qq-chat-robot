from __future__ import annotations
import asyncio
import json
import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star
_LOGGER = logging.getLogger(__name__)
from .feature import Feature
def _get_result_or_none(event: AstrMessageEvent) -> Any | None:
    """读取前置处理器留下的事件结果。"""
    try:
        return event.get_result()
    except AttributeError:
        return None

def _is_stopped(event: AstrMessageEvent) -> bool:
    """检查事件是否已停止传播。"""
    is_stopped = getattr(event, "is_stopped", None)
    return bool(is_stopped()) if callable(is_stopped) else False

def _result_has_reply(result: Any | None) -> bool:
    """空结果不算已回复。"""
    if isinstance(result, str):
        return bool(result.strip())
    return bool(getattr(result, "chain", None))

class Plugin(Feature, Star):
    slug = 'persona'
    label = '大肥鱼聊天与群聊接话'
    summary = '统一 QQ 人格、群聊接话、去重和回复修复。'
    turns = ()
    legacy = ()

    prepare_order = 90

    async def prepare(self, host, event, request, enabled):
        from app.astrbot_qq_persona import apply_qq_persona
        apply_qq_persona(host.context, event, request)
        host._get_group_router().prepare_request(event, request)

    async def message(self, host, event):
        from app.astrbot_failure_reply import install_send_guard
        install_send_guard(host.context, event)

    @filter.after_message_sent(priority=-300000)
    async def finish_group_reply(self, event: AstrMessageEvent):
        host = self.host()
        if host is None:
            return
        if host._group_router is not None:
            host._group_router.finish_event(event, sent=bool(getattr(event, "_has_send_oper", False)))
        if host._reply_guard is not None:
            host._reply_guard.mark_sent(event)

    @filter.on_llm_request(priority=-100)
    async def prepare_native_chat(self, event: AstrMessageEvent, request: Any) -> None:
        """普通聊天交给原生插件流程，保留每用户的角色与音色设置。"""
        host = self.host()
        if host is None:
            return
        self = host
        if self.legacy_chat or self.runtime is None:
            return
        from app.astrbot_chat import prepare_native_chat

        try:
            await prepare_native_chat(self.runtime, event, request)
        except Exception as exc:  # noqa: BLE001 -- 上下文补充失败不能中断其他插件聊天。
            _LOGGER.warning("补充原生聊天角色上下文失败（%s）", type(exc).__name__)
        from app.astrbot_identity import identity_question_kind, identity_request_prompt

        platform_getter = getattr(event, "get_platform_name", None)
        text_getter = getattr(event, "get_message_str", None)
        platform = str(platform_getter() if callable(platform_getter) else "").casefold()
        text = str(text_getter() if callable(text_getter) else "")
        if platform in {"aiocqhttp", "onebot", "onebot_v11"}:
            from app.services.usage_ledger import bind_event
            bind_event(event)
        if platform in {"aiocqhttp", "onebot", "onebot_v11"} and identity_question_kind(text) == "technical":
            request.system_prompt = str(getattr(request, "system_prompt", "") or "") + "\n" + identity_request_prompt(text)

    @filter.command("主动消息")
    async def proactive_group_settings(self, event: AstrMessageEvent) -> Any:
        """查看本群主动消息开关和频率。"""
        host = self.host()
        if host is None:
            return
        self = host
        from app.astrbot_plugin_status import proactive_group_status

        event.should_call_llm(False)
        event.stop_event()
        return event.make_result().message(proactive_group_status(self.context, event))

    @filter.on_llm_response(priority=-300000)
    async def repair_direct_group_reply(self, event: AstrMessageEvent, response: Any) -> None:
        """明确点名的答复跑偏时有界纠正，避免被避重拦下后毫无反馈。"""
        host = self.host()
        if host is None:
            return
        self = host
        if self.legacy_chat or self.runtime is None:
            return
        from app.astrbot_analysis_delivery import is_deferred_analysis_reply

        if is_deferred_analysis_reply(event):
            return
        from app.astrbot_identity import apply_character_identity

        if apply_character_identity(event, response, self._get_reply_guard()):
            return
        router = self._get_group_router()
        if not router.in_scope(event) or not router.allow_reply(event):
            return
        from app.astrbot_silence import is_silence_control_text

        if (event.get_extra("qqchat_group_reply_reason") == "interject"
                and is_silence_control_text(str(getattr(response, "completion_text", "") or ""))):
            response.completion_text = ""
            chain = getattr(response, "result_chain", None)
            if chain is not None:
                chain.chain = []
            router.suppress_reply(event)
            event.should_call_llm(False)
            event.stop_event()
            return
        outcome = await self._get_reply_repair().repair_response(self.context, event, response)
        if outcome == "notice_cooldown":
            router.finish_event(event)
            event.should_call_llm(False)
            event.stop_event()

    @filter.on_decorating_result(priority=100)
    async def suppress_repeated_group_reply(self, event: AstrMessageEvent) -> None:
        """先检查聊天原文，再交给语音和平台装饰；被拒绝的回复不会发出。"""
        host = self.host()
        if host is None:
            return
        self = host
        if self.legacy_chat or self.runtime is None:
            return
        router = self._get_group_router()
        if not router.in_scope(event) and not router.is_idle_event(event):
            return
        result = event.get_result()
        if result is None or not result.is_llm_result():
            return
        if not router.allow_reply(event):
            if self._reply_guard is not None:
                self._reply_guard.discard(event)
            event.clear_result()
            event.stop_event()
            router.finish_event(event)
            _LOGGER.info("群聊已要求安静，取消此前排队的聊天回复。")
            return
        reason = self._get_reply_guard().prepare_result(event)
        if reason:
            router.suppress_reply(event)
            _LOGGER.info("群聊发送前拦截无信息或重复回复：%s。", reason)

    @filter.on_decorating_result(priority=-100)
    async def filter_qq_source_links(self, event: AstrMessageEvent) -> None:
        """插件和原生回复里的国外链接也改成文字来源。"""
        host = self.host()
        if host is None:
            return
        self = host
        get_name = getattr(event, "get_platform_name", None)
        platform = str(get_name() if callable(get_name) else "").casefold()
        if not any(tag in platform for tag in ("qq", "aiocqhttp", "onebot")):
            return
        from astrbot.api.message_components import Plain

        from app.services.chat_punctuation import natural_chat_text, without_formatting_stars
        from app.services.outbound_links import sanitize_qq_source_links

        result = event.get_result()
        for component in getattr(result, "chain", ()) or ():
            if isinstance(component, Plain):
                component.text = sanitize_qq_source_links(without_formatting_stars(component.text))
                component.text = natural_chat_text(component.text)
        if not self.legacy_chat and self.runtime is not None:
            from app.astrbot_chat import decorate_native_voice

            try:
                await decorate_native_voice(self.runtime, event)
            except Exception as exc:  # noqa: BLE001 -- 语音失败必须保留原生文字结果。
                _LOGGER.warning("原生聊天语音处理失败，保留原结果（%s）", type(exc).__name__)

    @filter.on_decorating_result(priority=-310000)
    async def simplify_setting_confirmation(self, event: AstrMessageEvent) -> None:
        host = self.host()
        if host is None:
            return
        self = host
        from app.astrbot_settings_reply import simplify_qq_setting_result

        simplify_qq_setting_result(event)
