# 大肥鱼 · 安静自习

开启自习、暂停、继续或取消计时，到点在原会话提醒。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
