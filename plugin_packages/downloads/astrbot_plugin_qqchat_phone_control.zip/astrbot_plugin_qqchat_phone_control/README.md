# 大肥鱼 · 安卓手机助手

主人私聊查看运行机器人手机的电量和充电状态，或通过 Termux:API 请求振动和手电筒。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
