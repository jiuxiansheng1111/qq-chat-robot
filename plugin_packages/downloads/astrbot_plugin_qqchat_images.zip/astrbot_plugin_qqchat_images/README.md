# 大肥鱼 · 随机图片

发送动物和角色图片，已装画境拾珍时可转交二次元插图请求。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
