from __future__ import annotations
import asyncio
import json
import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star
_LOGGER = logging.getLogger(__name__)
from .feature import Feature
def _get_result_or_none(event: AstrMessageEvent) -> Any | None:
    """读取前置处理器留下的事件结果。"""
    try:
        return event.get_result()
    except AttributeError:
        return None

def _is_stopped(event: AstrMessageEvent) -> bool:
    """检查事件是否已停止传播。"""
    is_stopped = getattr(event, "is_stopped", None)
    return bool(is_stopped()) if callable(is_stopped) else False

def _result_has_reply(result: Any | None) -> bool:
    """空结果不算已回复。"""
    if isinstance(result, str):
        return bool(result.strip())
    return bool(getattr(result, "chain", None))

class Plugin(Feature, Star):
    slug = 'images'
    label = '随机图片'
    summary = '发送动物和角色图片，已装画境拾珍时可转交二次元插图请求。'
    turns = ()
    legacy = ('cat', 'pig', 'nailong', 'character_images')

    @filter.command("来一份二次元图片", alias={"来份二次元图片", "来一张二次元图片", "来张二次元图片"})
    async def anime_image_command(self, event: AstrMessageEvent):
        """从已启用图片源取一张二次元图片。"""
        host = self.host()
        if host is None:
            return
        await self.on_anime_image(event)

    @filter.event_message_type(filter.EventMessageType.ALL, priority=-90)
    async def on_anime_image(self, event: AstrMessageEvent):
        """明确要随机图片时交给 AstrBot 图片插件。"""
        host = self.host()
        if host is None:
            return
        self = host
        if _is_stopped(event) or _result_has_reply(_get_result_or_none(event)):
            return
        if getattr(event, "_has_send_oper", False):
            return
        if self.runtime is None:
            return
        from app.astrbot_menu import _raw_event_for_reset

        if not await self._legacy_event_allowed(_raw_event_for_reset(self, event)):
            return
        from app.astrbot_plugin_images import forward_anime_image

        results = await forward_anime_image(event, self.context)
        if results is None:
            return
        event.should_call_llm(False)
        from app.astrbot_failure_reply import install_send_guard
        install_send_guard(self.context,event)
        try:
            async for result in results:
                # The upstream handler stops the event before yielding. Send
                # its result here so the scheduler cannot discard the image.
                await event.send(result)
        finally:
            event.stop_event()
