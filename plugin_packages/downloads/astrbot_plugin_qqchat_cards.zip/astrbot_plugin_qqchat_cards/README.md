# 大肥鱼 · 炉石查卡

支持卡名、简称和相似名，确认候选后发送卡面、卡包和模式。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
