from __future__ import annotations
import asyncio
import json
import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star
_LOGGER = logging.getLogger(__name__)
from .feature import Feature
def _get_result_or_none(event: AstrMessageEvent) -> Any | None:
    """读取前置处理器留下的事件结果。"""
    try:
        return event.get_result()
    except AttributeError:
        return None

def _is_stopped(event: AstrMessageEvent) -> bool:
    """检查事件是否已停止传播。"""
    is_stopped = getattr(event, "is_stopped", None)
    return bool(is_stopped()) if callable(is_stopped) else False

def _result_has_reply(result: Any | None) -> bool:
    """空结果不算已回复。"""
    if isinstance(result, str):
        return bool(result.strip())
    return bool(getattr(result, "chain", None))

class Plugin(Feature, Star):
    slug = 'cards'
    label = '炉石查卡'
    summary = '支持卡名、简称和相似名，确认候选后发送卡面、卡包和模式。'
    turns = ()
    legacy = ()

    async def retry_lookup(self, host, event, mode, name):
        from .logic import handle
        return await handle(host, event, command=True, corrected=(mode, name))

    async def message(self, host, event):
        from .logic import handle
        return await handle(host, event)

    @filter.command("查卡", alias={"炉石查卡", "查询卡牌", "查询卡片", "卡牌查询", "卡片查询", "查卡确认"})
    async def lookup(self, event: AstrMessageEvent):
        """搜索卡名或简称，在玩家确认后发卡面和详情。"""
        host = self.host()
        if host is not None:
            from .logic import handle
            await handle(host, event, command=True)
