# 大肥鱼 · 大肥鱼表情

根据语境选择本机已配置的大肥鱼表情。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
