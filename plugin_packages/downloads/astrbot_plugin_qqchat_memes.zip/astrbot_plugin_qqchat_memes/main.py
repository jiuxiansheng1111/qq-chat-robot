from __future__ import annotations
import asyncio
import json
import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star
_LOGGER = logging.getLogger(__name__)
from .feature import Feature
def _get_result_or_none(event: AstrMessageEvent) -> Any | None:
    """读取前置处理器留下的事件结果。"""
    try:
        return event.get_result()
    except AttributeError:
        return None

def _is_stopped(event: AstrMessageEvent) -> bool:
    """检查事件是否已停止传播。"""
    is_stopped = getattr(event, "is_stopped", None)
    return bool(is_stopped()) if callable(is_stopped) else False

def _result_has_reply(result: Any | None) -> bool:
    """空结果不算已回复。"""
    if isinstance(result, str):
        return bool(result.strip())
    return bool(getattr(result, "chain", None))

class Plugin(Feature, Star):
    slug = 'memes'
    label = '大肥鱼表情'
    summary = '根据语境选择本机已配置的大肥鱼表情。'
    turns = ()
    legacy = ()

    async def prepare(self, host, event, request, enabled):
        host._get_qq_memes().prepare(host.context, event, request)

    @filter.after_message_sent(priority=-300000)
    async def finish_meme(self, event: AstrMessageEvent):
        host = self.host()
        if host is not None and host._qq_memes is not None:
            host._qq_memes.mark_sent(event)

    @filter.on_llm_response(priority=100001)
    async def select_whale_meme(self, event: AstrMessageEvent, response: Any) -> None:
        host = self.host()
        if host is None:
            return
        self = host
        self._get_qq_memes().process_response(event, response)

    @filter.on_decorating_result(priority=90)
    async def attach_whale_meme(self, event: AstrMessageEvent) -> None:
        host = self.host()
        if host is None:
            return
        self = host
        self._get_qq_memes().decorate(event)
