# 大肥鱼 · 纠正刚才的查询

根据本人的上次查卡、点歌或天气查询修正版本、歌手或城市；使用对话中已启用的对应工具。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
