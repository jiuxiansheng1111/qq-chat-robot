from __future__ import annotations
import asyncio
import json
import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star
_LOGGER = logging.getLogger(__name__)
from .feature import Feature
def _get_result_or_none(event: AstrMessageEvent) -> Any | None:
    """读取前置处理器留下的事件结果。"""
    try:
        return event.get_result()
    except AttributeError:
        return None

def _is_stopped(event: AstrMessageEvent) -> bool:
    """检查事件是否已停止传播。"""
    is_stopped = getattr(event, "is_stopped", None)
    return bool(is_stopped()) if callable(is_stopped) else False

def _result_has_reply(result: Any | None) -> bool:
    """空结果不算已回复。"""
    if isinstance(result, str):
        return bool(result.strip())
    return bool(getattr(result, "chain", None))

class Plugin(Feature, Star):
    slug = 'search'
    label = '联网检索与攻略'
    summary = '按问题查询公开资料，整理来源和攻略。'
    turns = ()
    legacy = ('web_search',)

    prepare_order = 70

    async def prepare(self, host, event, request, enabled):
        from app.astrbot_search import prepare_group_search_context
        from .logic import prepare_guide_context
        settings = host.runtime._core.settings
        await prepare_group_search_context(host.context, event, request, settings=settings,
                                           enabled=host.config.get("web_search_enabled", True),
                                           media_features=enabled)
        await prepare_guide_context(host.context, event, request, settings)

    @filter.llm_tool(name="qqchat_web_search")
    async def qqchat_web_search(
        self, event: AstrMessageEvent, query: str, recency: str = "noLimit",
    ) -> str:
        """联网查证近期新闻、新游戏、版本更新、陌生网梗和不确定事实，返回来源与日期。

        Args:
            query(string): 精简的搜索关键词，最多70字；补全当前话题的实体名，不要发送聊天记录或隐私资料。
            recency(string): 时间范围：oneDay一天内，oneWeek一周内，oneMonth一月内，oneYear一年内，noLimit不限。今天新闻选oneDay，最近消息选oneWeek，梗的来源或游戏知识可选noLimit。
        """
        host = self.host()
        if host is None:
            return '{"status":"unavailable","message":"请先启用大肥鱼共享运行时"}'
        self = host
        if not self.config.get("web_search_enabled", True):
            return '{"status":"disabled","message":"联网搜索已关闭。"}'
        from app.astrbot_search import native_web_search

        settings = getattr(getattr(self.runtime, "_core", None), "settings", None)
        return await native_web_search(self.context, event, query, recency, settings=settings)
