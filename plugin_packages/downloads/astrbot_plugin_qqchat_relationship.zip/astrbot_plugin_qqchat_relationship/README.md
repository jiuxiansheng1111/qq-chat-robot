# 大肥鱼 · 互动与好感

管理恋爱模式、好感状态以及互动历史。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
