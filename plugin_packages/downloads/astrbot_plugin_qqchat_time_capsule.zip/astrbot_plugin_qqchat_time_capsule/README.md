# 大肥鱼 · 群周年时间胶囊

按北京时间封存个人投稿，可以写话、留照片或语音，开封时在原群送出。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
