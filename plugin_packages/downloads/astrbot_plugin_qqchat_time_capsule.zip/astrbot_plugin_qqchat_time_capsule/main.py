from __future__ import annotations
import asyncio
import json
import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star
_LOGGER = logging.getLogger(__name__)
from .feature import Feature
def _get_result_or_none(event: AstrMessageEvent) -> Any | None:
    """读取前置处理器留下的事件结果。"""
    try:
        return event.get_result()
    except AttributeError:
        return None

def _is_stopped(event: AstrMessageEvent) -> bool:
    """检查事件是否已停止传播。"""
    is_stopped = getattr(event, "is_stopped", None)
    return bool(is_stopped()) if callable(is_stopped) else False

def _result_has_reply(result: Any | None) -> bool:
    """空结果不算已回复。"""
    if isinstance(result, str):
        return bool(result.strip())
    return bool(getattr(result, "chain", None))

class Plugin(Feature, Star):
    slug = 'time_capsule'
    label = '群周年时间胶囊'
    summary = '按北京时间封存个人投稿，可以写话、留照片或语音，开封时在原群送出。'
    turns = ()
    legacy = ()

    async def start_part(self, host):
        from app.astrbot_turn_features import start_timers
        start_timers(host, ("time_capsule",))
