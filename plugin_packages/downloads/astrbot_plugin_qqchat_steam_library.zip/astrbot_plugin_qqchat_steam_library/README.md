# 大肥鱼 · Steam 共同游戏库

比较本群玩家自愿共享的游戏，按实际参加人数和商店联机信息推荐，可以撤回自己的清单。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
