# 大肥鱼 · 点歌与歌词

搜歌、选择候选、查询歌词并发送音乐卡片。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
