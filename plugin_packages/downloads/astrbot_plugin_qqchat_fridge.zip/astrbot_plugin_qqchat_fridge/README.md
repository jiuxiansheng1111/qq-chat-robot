# 大肥鱼 · 冰箱食材搭配

根据文字或实际看清的食材照片、想先吃的食材和可用时间配菜。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
