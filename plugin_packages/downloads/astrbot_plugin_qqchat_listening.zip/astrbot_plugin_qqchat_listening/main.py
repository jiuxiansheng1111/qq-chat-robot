from __future__ import annotations
import asyncio
import json
import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star
_LOGGER = logging.getLogger(__name__)
from .feature import Feature
def _get_result_or_none(event: AstrMessageEvent) -> Any | None:
    """读取前置处理器留下的事件结果。"""
    try:
        return event.get_result()
    except AttributeError:
        return None

def _is_stopped(event: AstrMessageEvent) -> bool:
    """检查事件是否已停止传播。"""
    is_stopped = getattr(event, "is_stopped", None)
    return bool(is_stopped()) if callable(is_stopped) else False

def _result_has_reply(result: Any | None) -> bool:
    """空结果不算已回复。"""
    if isinstance(result, str):
        return bool(result.strip())
    return bool(getattr(result, "chain", None))

class Plugin(Feature, Star):
    slug = 'listening'
    label = '网易云一起听'
    summary = '接受一起听邀请，处理房间消息和经授权保存的听歌记录。'
    turns = ()
    legacy = ()

    async def start_part(self, host):
        import asyncio
        service = host._get_music_listening()
        self.recovery = asyncio.create_task(service.restore(host.runtime._core.settings, host.context,
                                                            route_allowed=host._legacy_event_allowed))

    async def stop_part(self, host):
        import asyncio
        self.recovery.cancel()
        await asyncio.gather(self.recovery, return_exceptions=True)
        await host._music_listening.close(preserve=True)
        host._music_listening = None

    async def message(self, host, event):
        host._get_music_listening().observe(event)

    async def prepare(self, host, event, request, enabled):
        from app.astrbot_qq_persona import is_qq
        if is_qq(event):
            host._get_music_listening().prepare(event, request)

    @filter.llm_tool(name="qqchat_listen_music")
    async def qqchat_listen_music(self, event: AstrMessageEvent, query: str = "", action: str = "listen") -> str:
        """和用户一起听网易云歌曲并自然评价；后台真实听取，完成后主动回复并长期记住歌曲和听感，期间可继续聊天。收到有效一起听房间邀请时要实际加入。

        Args:
            query(string): 网易云歌名加歌手、歌曲编号或官方歌曲链接；不要传本机路径。
            action(string): listen听取评价歌曲；join接受本轮消息或引用中的真实一起听邀请；leave停止当前用户发起的陪听。
        """
        host = self.host()
        if host is None:
            return '{"status":"unavailable","message":"请先启用大肥鱼共享运行时"}'
        self = host
        from app.astrbot_qq_persona import is_qq
        if not is_qq(event) or self.runtime is None:
            return '{"status":"unavailable"}'
        raw = getattr(getattr(event,"message_obj",None),"raw_message",None)
        if not await self._legacy_event_allowed(raw):
            return '{"status":"denied"}'
        try:
            result=await self._get_music_listening().call(event,self.runtime._core.settings,self.context,query,action)
            return json.dumps(result,ensure_ascii=False)
        except Exception as exc:
            from app.services.netease_member import NeteaseMemberError
            message=str(exc) if isinstance(exc,NeteaseMemberError) else "这次未取得有效歌曲或房间连接，尚未开始听取"
            return json.dumps({"status":"failed","message":message},ensure_ascii=False)

    @filter.llm_tool(name="qqchat_music_room_message")
    async def qqchat_music_room_message(self, event: AstrMessageEvent, action: str = "status", text: str = "") -> str:
        """在当前用户从这个QQ会话邀请加入的网易云一起听房间读取或发送文字留言。普通QQ聊天留在QQ，不自动转发；只能使用已绑定房间，不能指定其他房间。

        Args:
            action(string): status查询房间留言连接；read读取最近留言；send发送用户明确要求的文字。
            text(string): send时的实际留言，1至500字符；其他操作留空。
        """
        host = self.host()
        if host is None:
            return '{"status":"unavailable","message":"请先启用大肥鱼共享运行时"}'
        self = host
        from app.astrbot_qq_persona import is_qq
        if not is_qq(event) or self.runtime is None:
            return '{"status":"unavailable","success":false}'
        raw=getattr(getattr(event,"message_obj",None),"raw_message",None)
        if not await self._legacy_event_allowed(raw):
            return '{"status":"denied","success":false}'
        result=await self._get_music_listening().room_message(event,self.runtime._core.settings,action,text)
        return json.dumps(result,ensure_ascii=False)

    @filter.llm_tool(name="qqchat_music_artist")
    async def qqchat_music_artist(self, event: AstrMessageEvent, query: str) -> str:
        """核实歌手身份、别名、中文名和日文名，返回网易云候选及来源。先核对再评价；结果不足时继续联网搜索，不把重名者混为一人。

        Args:
            query(string): 歌手名或别名，不包含私聊记录或账号资料。
        """
        host = self.host()
        if host is None:
            return '{"status":"unavailable","message":"请先启用大肥鱼共享运行时"}'
        self = host
        from app.astrbot_qq_persona import is_qq
        from app.astrbot_listening import artist_lookup
        from app.astrbot_search import _private_query
        if not is_qq(event) or self.runtime is None or _private_query(query,event):
            return '{"status":"unavailable"}'
        if not await self._legacy_event_allowed(getattr(event.message_obj,"raw_message",None)):
            return '{"status":"denied"}'
        try:
            result=await artist_lookup(query,self.runtime._core.settings)
            from app.astrbot_soundtry import SoundtryJobs
            memory=self._get_music_listening().memory
            names=[str(a.get("name", "")) for a in result.get("candidates",[])]
            from app.services.owner_policy import is_owner_event, load_owner_policy
            recalled=(memory.summaries(SoundtryJobs.owner(event)," ".join(names))
                      if is_owner_event(event) and load_owner_policy().music_profile_enabled else [])
            result["listening_history"]=[row for row in recalled if any(n and n in row["artists"] for n in names)]
            return json.dumps(result,ensure_ascii=False)
        except Exception:
            return '{"status":"unavailable","message":"歌手身份未核实，可以继续联网查询"}'

    @filter.llm_tool(name="qqchat_music_portrait")
    async def qqchat_music_portrait(self, event: AstrMessageEvent, query: str = "", experience_id: int = 0, offset: int = 0) -> str:
        """回忆当前主人在本会话的长期音乐画像，包含真实听过的歌、主人明确表达的偏好和本鱼的听感。听过不等于喜欢，听感不冒充主人的意见。

        Args:
            query(string): 歌手、别名或歌名关键词，留空查看近期经历。
            experience_id(number): 留0查画像，或传listening_events中的id阅读该次完整证据与听感。
            offset(number): 查画像时为经历列表起点，读完整听感时为字符起点。
        """
        host = self.host()
        if host is None:
            return '{"status":"unavailable","message":"请先启用大肥鱼共享运行时"}'
        self = host
        from app.astrbot_owner_memory import music_portrait
        if self.runtime is None or not await self._legacy_event_allowed(getattr(event.message_obj,"raw_message",None)):
            return '{"status":"denied"}'
        result=await asyncio.to_thread(music_portrait,event,self._get_music_listening().memory,query,experience_id,offset)
        return json.dumps(result,ensure_ascii=False)
