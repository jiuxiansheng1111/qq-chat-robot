# 大肥鱼 · 网易云一起听

接受一起听邀请，处理房间消息和经授权保存的听歌记录。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
