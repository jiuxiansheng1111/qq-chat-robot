# 大肥鱼 · Windows 电脑助手

主人私聊让电脑开计算器、记事本或画图，查看当前窗口、锁屏和控制多媒体键。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
