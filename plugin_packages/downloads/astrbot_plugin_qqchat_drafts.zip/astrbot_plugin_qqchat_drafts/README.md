# 大肥鱼 · 回复草稿

结合当前会话的引用或图片拟回复，支持改写语气。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
