from __future__ import annotations
import asyncio
import json
import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star
_LOGGER = logging.getLogger(__name__)
from .feature import Feature
def _get_result_or_none(event: AstrMessageEvent) -> Any | None:
    """读取前置处理器留下的事件结果。"""
    try:
        return event.get_result()
    except AttributeError:
        return None

def _is_stopped(event: AstrMessageEvent) -> bool:
    """检查事件是否已停止传播。"""
    is_stopped = getattr(event, "is_stopped", None)
    return bool(is_stopped()) if callable(is_stopped) else False

def _result_has_reply(result: Any | None) -> bool:
    """空结果不算已回复。"""
    if isinstance(result, str):
        return bool(result.strip())
    return bool(getattr(result, "chain", None))

class Plugin(Feature, Star):
    slug = 'group_reports'
    label = '群报与日历查询'
    summary = '按日期调取当前群的群报，支持既有群分析插件。'
    turns = ()
    legacy = ()

    @filter.command("群报", alias={"群总结", "群日报"})
    async def calendar_group_reports(self, event: AstrMessageEvent, date_text: str = ""):
        """群报默认昨日＋今日；群报 昨天 / 群报 YYYY-MM-DD 仅补发指定一天。"""
        host = self.host()
        if host is None:
            return
        self = host
        event.should_call_llm(False)
        event.stop_event()
        router = self._get_group_router()
        raw = getattr(getattr(event, "message_obj", None), "raw_message", None)
        if (self.runtime is None or not router.in_scope(event) or router.ignored_sender(event)
                or not await self._legacy_event_allowed(raw)):
            await event.send(event.plain_result("请在已启用的本群里请求群报。"))
            return
        from astrbot.api.message_components import Image, Plain

        from app.astrbot_group_reports import request_group_reports

        # stop_event ends AstrBot's generator pipeline at the next yield. Keep
        # this command's preparation and final report in its owned send flow.
        if date_text:
            await event.send(event.plain_result("我去整理这一天的群报～如果是今天，统计到上一完整分钟。"))
            batch = await request_group_reports(self.context, event, date_text=date_text)
        else:
            await event.send(event.plain_result("我去整理昨天和今天的两份群报～今日统计到上一完整分钟。"))
            batch = await request_group_reports(self.context, event)
        if not batch.items:
            await event.send(event.plain_result(batch.message or "群报暂时没整理好，稍后再试一下。"))
            return
        chain = []
        for item in batch.items:
            chain.append(Plain(item.header + ("\n" + item.text if item.text else "") + "\n"))
            if item.image_path:
                chain.append(Image.fromFileSystem(item.image_path))
        await event.send(event.chain_result(chain))
