# 大肥鱼 · 群报与日历查询

按日期调取当前群的群报，支持既有群分析插件。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
