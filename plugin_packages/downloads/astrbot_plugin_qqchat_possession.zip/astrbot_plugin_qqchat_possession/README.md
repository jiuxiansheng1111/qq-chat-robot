# 大肥鱼 · 群聊角色扮演

随机或指定群成员进行角色扮演，查看与退出当前身份。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
