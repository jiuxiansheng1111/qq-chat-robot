# 大肥鱼 · 家里的设备

主人在私聊里开灯、调空调和音量，执行已绑定的电脑、手机动作或灯光音乐场景。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
