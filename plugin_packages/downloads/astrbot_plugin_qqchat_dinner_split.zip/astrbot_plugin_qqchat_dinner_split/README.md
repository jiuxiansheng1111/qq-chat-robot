# 大肥鱼 · 聚餐 AA

多人垫付、按菜分摊、确认小票、撤销和按分结算。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
