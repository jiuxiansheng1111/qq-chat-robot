from __future__ import annotations
import asyncio
import json
import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star
_LOGGER = logging.getLogger(__name__)
from .feature import Feature
def _get_result_or_none(event: AstrMessageEvent) -> Any | None:
    """读取前置处理器留下的事件结果。"""
    try:
        return event.get_result()
    except AttributeError:
        return None

def _is_stopped(event: AstrMessageEvent) -> bool:
    """检查事件是否已停止传播。"""
    is_stopped = getattr(event, "is_stopped", None)
    return bool(is_stopped()) if callable(is_stopped) else False

def _result_has_reply(result: Any | None) -> bool:
    """空结果不算已回复。"""
    if isinstance(result, str):
        return bool(result.strip())
    return bool(getattr(result, "chain", None))

class Plugin(Feature, Star):
    slug = 'weather'
    label = '实时天气'
    summary = '查城市天气、体感与穿衣建议，也可按机器人网络定位。说「深圳下雨或变天时提醒我」可在傍晚收到次日提醒，「取消天气提醒」可关闭。'
    turns = ()
    legacy = ('weather',)

    async def start_part(self, host):
        from app.astrbot_weather_alerts import service_for
        service_for(host).start(host)

    async def stop_part(self, host):
        await host._weather_alerts.close()
        host._weather_alerts = None

    async def message(self, host, event):
        from .logic import handle_command
        return await handle_command(host, event)

    async def prepare(self, host, event, request, enabled):
        from .logic import prepare
        prepare(event, request)

    @filter.command("天气", alias={"weather"})
    async def weather_command(self, event: AstrMessageEvent, city: str = ""):
        """查询指定城市的天气。"""
        host = self.host()
        if host is None:
            return
        from .logic import deliver
        await deliver(host, event, city)

    @filter.llm_tool(name="qqchat_weather")
    async def qqchat_weather(self, event: AstrMessageEvent, location: str = "") -> str:
        """查询当前天气、体感与三天预报。省略城市优先用本人设置，其次用标明来源的机器人网络估算。

        Args:
            location(string): 城市名、我这里或本机。用户明确问自己所在地时传我这里。
        """
        host = self.host()
        if host is None:
            return '{"status":"unavailable","message":"请先启用大肥鱼共享运行时"}'
        self = host
        from .logic import query
        return json.dumps(await query(self, event, location), ensure_ascii=False)
