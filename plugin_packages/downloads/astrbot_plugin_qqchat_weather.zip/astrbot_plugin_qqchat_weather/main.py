from __future__ import annotations
import asyncio
import json
import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star
_LOGGER = logging.getLogger(__name__)
from .feature import Feature
def _get_result_or_none(event: AstrMessageEvent) -> Any | None:
    """读取前置处理器留下的事件结果。"""
    try:
        return event.get_result()
    except AttributeError:
        return None

def _is_stopped(event: AstrMessageEvent) -> bool:
    """检查事件是否已停止传播。"""
    is_stopped = getattr(event, "is_stopped", None)
    return bool(is_stopped()) if callable(is_stopped) else False

def _result_has_reply(result: Any | None) -> bool:
    """空结果不算已回复。"""
    if isinstance(result, str):
        return bool(result.strip())
    return bool(getattr(result, "chain", None))

class Plugin(Feature, Star):
    slug = 'weather'
    label = '实时天气'
    summary = '识别自然语言城市名，查询实时天气和预报。'
    turns = ()
    legacy = ('weather',)

    async def message(self, host, event):
        from .logic import handle_command
        return await handle_command(host, event)

    async def prepare(self, host, event, request, enabled):
        from .logic import prepare
        prepare(event, request)

    @filter.command("天气", alias={"weather"})
    async def weather_command(self, event: AstrMessageEvent, city: str = ""):
        """查询指定城市的天气。"""
        host = self.host()
        if host is None:
            return
        from .logic import query
        result = await query(host, event, city)
        if result["status"] == "denied":
            return
        text = result.get("report") or ("想查哪个城市的天气？" if not city else "暂时没有查到这座城市的天气。")
        await event.send(event.plain_result(text))
        event.should_call_llm(False)
        event.stop_event()

    @filter.llm_tool(name="qqchat_weather")
    async def qqchat_weather(self, event: AstrMessageEvent, location: str) -> str:
        """查询城市当前天气和未来三天预报，返回真实天气数据。天气问题优先用此工具，缺城市时先询问。

        Args:
            location(string): 城市或地区名称，例如深圳；只传地点，不传聊天记录。
        """
        host = self.host()
        if host is None:
            return '{"status":"unavailable","message":"请先启用大肥鱼共享运行时"}'
        self = host
        from .logic import query
        return json.dumps(await query(self, event, location), ensure_ascii=False)
