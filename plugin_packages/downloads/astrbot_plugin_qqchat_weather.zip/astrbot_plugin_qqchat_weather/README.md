# 大肥鱼 · 实时天气

查城市天气、体感与穿衣建议，也可按机器人网络定位。说「深圳下雨或变天时提醒我」可在傍晚收到次日提醒，「取消天气提醒」可关闭。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
