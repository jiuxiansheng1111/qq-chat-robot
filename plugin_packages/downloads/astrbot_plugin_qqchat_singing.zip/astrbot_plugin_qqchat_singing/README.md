# 大肥鱼 · 点唱与翻唱

使用已配置的角色音色演唱，支持片段、状态和取消。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
