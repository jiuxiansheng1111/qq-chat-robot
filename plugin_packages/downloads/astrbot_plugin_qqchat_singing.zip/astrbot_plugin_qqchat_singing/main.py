from __future__ import annotations
import asyncio
import json
import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star
_LOGGER = logging.getLogger(__name__)
from .feature import Feature
def _get_result_or_none(event: AstrMessageEvent) -> Any | None:
    """读取前置处理器留下的事件结果。"""
    try:
        return event.get_result()
    except AttributeError:
        return None

def _is_stopped(event: AstrMessageEvent) -> bool:
    """检查事件是否已停止传播。"""
    is_stopped = getattr(event, "is_stopped", None)
    return bool(is_stopped()) if callable(is_stopped) else False

def _result_has_reply(result: Any | None) -> bool:
    """空结果不算已回复。"""
    if isinstance(result, str):
        return bool(result.strip())
    return bool(getattr(result, "chain", None))

class Plugin(Feature, Star):
    slug = 'singing'
    label = '点唱与翻唱'
    summary = '使用已配置的角色音色演唱，支持片段、状态和取消。'
    turns = ()
    legacy = ('singing',)

    async def message(self, host, event):
        from app.astrbot_singing import handle_command
        return await handle_command(host, event)

    async def prepare(self, host, event, request, enabled):
        from app.astrbot_singing import prepare_audio_capabilities
        await prepare_audio_capabilities(host.runtime._core, event, request)

    @filter.llm_tool(name="qqchat_sing")
    async def qqchat_sing(self, event: AstrMessageEvent, query: str = "", voice: str = "", mode: str = "full", action: str = "sing") -> str:
        """真正演唱并发送当前QQ会话点的歌，复用已安装的翻唱引擎。只有明确点唱才提交，询问会不会唱时按能力说明回答，缺歌名先询问。接收后后台生成，期间可以聊天，不重复接单，完成后发送真实歌声。普通说话用qqchat_send_voice，朗读歌词不等于唱歌。

        Args:
            query(string): 歌名与歌手，或网易云歌曲链接。不能虚构对方点的歌。
            voice(string): 留空使用当前选择或默认大肥鱼音色，临时指定也不会切换人格。
            mode(string): full唱整首，clip唱几句或一小段，按本轮请求选择。
            action(string): sing演唱，status查当前用户本会话任务，cancel停止，voices查询可唱音色。
        """
        host = self.host()
        if host is None:
            return '{"status":"unavailable","message":"请先启用大肥鱼共享运行时"}'
        self = host
        from app.astrbot_singing import singing_action
        return json.dumps(await singing_action(self,event,query=query,voice=voice,mode=mode,action=action),ensure_ascii=False)
