# 大肥鱼 · 等我说完

分几条发送文字、截图和语音，说完后集中回复；群里按发起人分别收取。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
