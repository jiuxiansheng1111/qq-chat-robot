# 大肥鱼 · 视频搜索与观看

搜索 B 站视频，读取视频内容并按时间点放大细节。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
