from __future__ import annotations
import asyncio
import json
import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star
_LOGGER = logging.getLogger(__name__)
from .feature import Feature
def _get_result_or_none(event: AstrMessageEvent) -> Any | None:
    """读取前置处理器留下的事件结果。"""
    try:
        return event.get_result()
    except AttributeError:
        return None

def _is_stopped(event: AstrMessageEvent) -> bool:
    """检查事件是否已停止传播。"""
    is_stopped = getattr(event, "is_stopped", None)
    return bool(is_stopped()) if callable(is_stopped) else False

def _result_has_reply(result: Any | None) -> bool:
    """空结果不算已回复。"""
    if isinstance(result, str):
        return bool(result.strip())
    return bool(getattr(result, "chain", None))

class Plugin(Feature, Star):
    slug = 'video'
    label = '视频搜索与观看'
    summary = '搜索 B 站视频，读取视频内容并按时间点放大细节。'
    turns = ()
    legacy = ('bilibili_video',)

    prepare_order = 30

    async def prepare(self, host, event, request, enabled):
        from app.astrbot_video import prepare_group_video_context
        await prepare_group_video_context(host.context, event, request, settings=host.runtime._core.settings)

    @filter.llm_tool(name="qqchat_video_detail")
    async def qqchat_video_detail(self, event: AstrMessageEvent, time_seconds: float = 0, region: str = "0,0,1,1", source: int = 0) -> str:
        """核对当前或引用的视频某时刻及小字。按video-watch-plus技能实际截取并放大局部画面，再由视觉接口读取；不凭缩图猜文字。

        Args:
            time_seconds(number): 原始视频里的秒数，0至1800。
            region(string): 归一化区域x,y,宽,高，各项0至1，如0,0.7,1,0.3表示画面底部三成。
            source(number): 本轮真实视频附件或链接的序号，从0开始。不接受任意网址或文件路径。
        """
        host = self.host()
        if host is None:
            return '{"status":"unavailable","message":"请先启用大肥鱼共享运行时"}'
        self = host
        from app.astrbot_qq_persona import is_qq
        from app.astrbot_video_skill import read_detail
        if not is_qq(event) or self.runtime is None or not await self._legacy_event_allowed(getattr(event.message_obj,"raw_message",None)):
            return '{"status":"unavailable"}'
        if isinstance(source,float) and source.is_integer():source=int(source)
        try:
            async with asyncio.timeout(150):
                result=await read_detail(self.context,event,self.runtime._core.settings,time_seconds,region,source)
            return json.dumps(result,ensure_ascii=False)
        except Exception as exc:
            message=str(exc)[:200] if isinstance(exc,ValueError) else "本次放大读取未完成，不可据此猜测小字"
            return json.dumps({"status":"failed","message":message},ensure_ascii=False)
