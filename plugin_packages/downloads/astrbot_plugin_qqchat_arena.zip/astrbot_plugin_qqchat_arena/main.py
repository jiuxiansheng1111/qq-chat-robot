from __future__ import annotations
import asyncio
import json
import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star
_LOGGER = logging.getLogger(__name__)
from .feature import Feature
def _get_result_or_none(event: AstrMessageEvent) -> Any | None:
    """读取前置处理器留下的事件结果。"""
    try:
        return event.get_result()
    except AttributeError:
        return None

def _is_stopped(event: AstrMessageEvent) -> bool:
    """检查事件是否已停止传播。"""
    is_stopped = getattr(event, "is_stopped", None)
    return bool(is_stopped()) if callable(is_stopped) else False

def _result_has_reply(result: Any | None) -> bool:
    """空结果不算已回复。"""
    if isinstance(result, str):
        return bool(result.strip())
    return bool(getattr(result, "chain", None))

class Plugin(Feature, Star):
    slug = 'arena'
    label = '炉石竞技场'
    summary = '比较选牌候选，添加或撤销已选卡并分析本轮牌组。'
    turns = ()
    legacy = ()

    prepare_order = 35

    async def prepare(self, host, event, request, enabled):
        from app.astrbot_hearthstone import prepare
        await prepare(host, event, request, decks=False, cards=False)

    @filter.command("竞技场选牌", alias={"竞技场选卡", "竞技场开始", "竞技场已选", "竞技场添加", "竞技场牌组", "竞技场撤销"})
    async def arena_command(self, event: AstrMessageEvent):
        """炉石竞技场三选一、传奇组合比较及本人已选牌记录。"""
        host = self.host()
        if host is None:
            return
        self = host
        from app.astrbot_hearthstone import wake_command
        await wake_command(self, event)

    @filter.llm_tool(name="qqchat_arena")
    async def qqchat_arena(
        self, event: AstrMessageEvent, action: str = "pick", choices: str = "",
        player_class: str = "", cards: str = "", choice_index: int = 0,
    ) -> str:
        """炉石竞技场选牌：核对实际卡名/效果、HearthArena职业评分和职业统计，结合已选牌分析。

        Args:
            action(string): pick比较候选、start明确开始新一轮、add记录用户明确已选的牌、status分析已选牌组、undo撤销上次添加；建议不自动添加。
            choices(string): pick用|分隔三组选项，如火球术|烈焰风暴|奥术智慧；传奇组合内部用+。截图先按视觉摘要提取准确卡名及从左到右顺序。
            player_class(string): 中文或英文职业；双职业写法师+潜行者；省略沿用本人本轮记录。
            cards(string): add的已选卡名，多个用|分隔，重复可写火球术x3；只记用户实际已选牌，不填推荐。
            choice_index(number): add可选本人上一轮比较中的第1至3项，默认0改用cards；传奇组合会整组加入。
        """
        host = self.host()
        if host is None:
            return '{"status":"unavailable","message":"请先启用大肥鱼共享运行时"}'
        self = host
        from app.astrbot_arena import query as arena_query
        return json.dumps(await arena_query(
            self, event, action=action, choices=choices, player_class=player_class,
            cards=cards, choice_index=choice_index,
        ), ensure_ascii=False)
