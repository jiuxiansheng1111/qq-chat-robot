# 大肥鱼 · 炉石竞技场

比较选牌候选，添加或撤销已选卡并分析本轮牌组。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
