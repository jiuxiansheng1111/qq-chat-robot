# 大肥鱼 · 群狼人杀

正式桌或单人练习，五种身份、私聊夜间行动、轮次投票和胜负结算。大肥鱼用自己的身份信息参与。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
