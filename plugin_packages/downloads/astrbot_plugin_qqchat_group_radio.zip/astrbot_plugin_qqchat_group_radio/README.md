# 大肥鱼 · 群轮值电台

主持人按报名顺序轮值，每人选一首真实歌曲并配文字或语音串词。播出和回听本群最近四期。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
