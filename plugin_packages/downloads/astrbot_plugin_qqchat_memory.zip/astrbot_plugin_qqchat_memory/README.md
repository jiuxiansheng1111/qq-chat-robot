# 大肥鱼 · 记忆与主人档案

管理手动记忆和经过本人配置的、按会话隔离的主人档案。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
