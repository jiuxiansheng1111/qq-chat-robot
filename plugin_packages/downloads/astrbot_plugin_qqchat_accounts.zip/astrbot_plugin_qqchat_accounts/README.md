# 大肥鱼 · 本机账号管理

集中管理 Minecraft、Steam、雀魂、网易云、ChatGPT 和 B 站的本机账号。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
