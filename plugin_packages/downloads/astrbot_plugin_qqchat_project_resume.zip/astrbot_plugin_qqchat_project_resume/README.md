# 大肥鱼 · 周末接着做

保存项目进度、卡点、下一步和草稿照片，回到原会话可以接着做。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
