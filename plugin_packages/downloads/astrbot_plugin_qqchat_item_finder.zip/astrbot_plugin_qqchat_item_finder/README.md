# 大肥鱼 · 用照片找物品

保存自己指定的物品、位置和照片，按当前会话找回或删除。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
