from __future__ import annotations
import asyncio
import json
import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star
_LOGGER = logging.getLogger(__name__)
from .feature import Feature
def _get_result_or_none(event: AstrMessageEvent) -> Any | None:
    """读取前置处理器留下的事件结果。"""
    try:
        return event.get_result()
    except AttributeError:
        return None

def _is_stopped(event: AstrMessageEvent) -> bool:
    """检查事件是否已停止传播。"""
    is_stopped = getattr(event, "is_stopped", None)
    return bool(is_stopped()) if callable(is_stopped) else False

def _result_has_reply(result: Any | None) -> bool:
    """空结果不算已回复。"""
    if isinstance(result, str):
        return bool(result.strip())
    return bool(getattr(result, "chain", None))

class Plugin(Feature, Star):
    slug = 'minecraft'
    label = 'Minecraft 独立玩家'
    summary = '进入 Java 服务器，采集材料、自主休息、查看背包或退服。含 Minecraft 文本、语音与音乐桥。'
    turns = ('mc',)
    legacy = ()

    async def start_part(self, host):
        from app.minecraft_bridge import MinecraftBridge
        runtime = host.runtime._core
        self.bridge = MinecraftBridge(runtime.app.state.llm, host.root, settings=runtime.settings)
        await self.bridge.start()

    async def stop_part(self, host):
        if host._companion_turns:
            await host._companion_turns.games.mc.close()
        await self.bridge.close()
