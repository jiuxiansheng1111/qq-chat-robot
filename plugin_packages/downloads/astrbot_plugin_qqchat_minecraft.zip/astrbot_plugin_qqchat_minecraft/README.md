# 大肥鱼 · Minecraft 独立玩家

进入 Java 服务器，采集材料、自主休息、查看背包或退服。含 Minecraft 文本、语音与音乐桥。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
