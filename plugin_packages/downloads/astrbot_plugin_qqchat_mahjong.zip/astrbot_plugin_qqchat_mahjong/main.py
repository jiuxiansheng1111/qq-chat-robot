from __future__ import annotations
import asyncio
import json
import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Star
_LOGGER = logging.getLogger(__name__)
from .feature import Feature
def _get_result_or_none(event: AstrMessageEvent) -> Any | None:
    """读取前置处理器留下的事件结果。"""
    try:
        return event.get_result()
    except AttributeError:
        return None

def _is_stopped(event: AstrMessageEvent) -> bool:
    """检查事件是否已停止传播。"""
    is_stopped = getattr(event, "is_stopped", None)
    return bool(is_stopped()) if callable(is_stopped) else False

def _result_has_reply(result: Any | None) -> bool:
    """空结果不算已回复。"""
    if isinstance(result, str):
        return bool(result.strip())
    return bool(getattr(result, "chain", None))

class Plugin(Feature, Star):
    slug = 'mahjong'
    label = '雀魂复盘与何切'
    summary = '按牌谱链接复盘，组织友人场或练习何切。'
    turns = ('mj',)
    legacy = ('mahjong_review',)

    async def message(self, host, event):
        from app.astrbot_mahjong import deliver_native_review, request_args
        args = request_args(event, host.runtime._core.app.state)
        if args is None:
            return False
        event.should_call_llm(False)
        event.stop_event()
        await deliver_native_review(host.runtime, event, args)
        return True
