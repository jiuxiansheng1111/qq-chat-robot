# 大肥鱼 · 雀魂复盘与何切

按牌谱链接复盘，组织友人场或练习何切。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
