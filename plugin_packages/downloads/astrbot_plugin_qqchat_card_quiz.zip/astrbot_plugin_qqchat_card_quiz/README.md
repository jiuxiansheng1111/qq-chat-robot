# 大肥鱼 · 群聊猜炉石卡

根据卡画猜卡名或简称，逐步给费用、职业、效果提示，揭晓时翻完整卡面。

先安装同版本的大肥鱼共享运行时，再从 AstrBot 插件页安装此 ZIP。

[安装与配置](https://github.com/jiuxiansheng1111/qq-chat-robot/blob/main/plugin_packages/README.md)
